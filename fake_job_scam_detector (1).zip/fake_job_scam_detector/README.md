# Fake Job Scam Detector

Web application for Chapter 4 of the project. A job seeker pastes a job advert; the system scores it with
**detection rules** and a **machine learning classifier**, then shows a Low / Medium / High rating with reasons.
Users can report adverts, and administrators review reports, manage rules, users and awareness tips.

Built with Python, Flask and MySQL, following the three-tier design in Figure 4.1.

## Folder map (matches the design)

| Design item | File |
|---|---|
| Boundary objects (pages) | `app/templates/` |
| Control objects (controllers) | `app/blueprints/auth.py`, `advert.py`, `report.py`, `admin.py` |
| RuleEngine, MLClassifier, RiskRater | `app/services/rule_engine.py`, `ml_classifier.py`, `risk_rater.py` |
| Security module | `app/security.py` (hashing, roles, CSRF, login throttle) |
| Database schema (Figure 4.11) | `schema_mysql.sql` (MySQL), `schema_sqlite.sql` (testing) |
| Starter detection rules and tips | `app/seed.py` |
| Model training | `train_model.py` |

## Setup (Windows with XAMPP, or any computer with MySQL)

1. Install Python 3.10+ and start MySQL (XAMPP: start **MySQL** in the control panel).
2. Create the database: in phpMyAdmin or the MySQL shell run
   `CREATE DATABASE jobscam CHARACTER SET utf8mb4;`
3. In this folder:
   ```
   python -m venv venv
   venv\Scripts\activate            (Linux/Mac: source venv/bin/activate)
   pip install -r requirements.txt
   copy .env.example .env           (Linux/Mac: cp .env.example .env)
   ```
   Edit `.env`: set `SECRET_KEY` and `DATABASE_URL` (for example `mysql://root:@localhost:3306/jobscam`).
4. Create the tables and starter rules, then the first administrator:
   ```
   flask --app run init-db
   flask --app run create-admin
   ```
5. Train the machine learning model (see below), then start the site:
   ```
   python run.py
   ```
   Open http://127.0.0.1:5000. Register a job seeker account from the home page; log in with the administrator
   account to reach the admin dashboard.

To try the project without MySQL, set `DATABASE_URL=sqlite:///dev.db` in `.env`.

## Training the classifier (EMSCAD)

1. Download the EMSCAD dataset `fake_job_postings.csv` (Kaggle: "Real or Fake Job Posting Prediction") into `data/`.
2. Run `python train_model.py --csv data/fake_job_postings.csv`.
   It prints precision, recall and F1 on a 20% test split (NFR5) and saves `models/scam_model.joblib`.
3. `python train_model.py --demo` trains on a tiny built-in set so you can test the pipeline. Do not use it for real results.

If no model file exists, the system still works: the final score is the rule score alone.

## How the score works

`final = 0.6 x rule score + 0.4 x (ML probability x 100)`; below 25 is Low, 25 to 54 Medium, 55 or more High.
Change the weights and thresholds in `config.py`. Administrators change the rules from the dashboard, no code needed.

## Tests

`pytest` (12 tests: login errors, hashing, CSRF, masking, role checks, report to confirmed-scam flow, rules, ML).

## Before going live

Set a long random `SECRET_KEY`, set `SESSION_COOKIE_SECURE=1`, serve over HTTPS (for example `gunicorn run:app`
behind Nginx), and never run with `debug=True`.
