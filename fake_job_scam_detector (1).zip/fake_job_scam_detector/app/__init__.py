from datetime import datetime

import click
from flask import Flask, render_template, session
from werkzeug.security import generate_password_hash

from config import Config
from .db import close_db, get_db, init_db
from .security import check_csrf, csrf_token, load_user
from .services.ml_classifier import MLClassifier
from .services.risk_rater import RiskRater
from .services.rule_engine import RuleEngine


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)

    # processing components of the application tier (Figure 4.1)
    app.extensions["rule_engine"] = RuleEngine()
    app.extensions["ml"] = MLClassifier(app.config["MODEL_PATH"])
    app.extensions["rater"] = RiskRater(app.config["RULE_WEIGHT"], app.config["ML_WEIGHT"],
                                        app.config["LOW_BELOW"], app.config["HIGH_FROM"])

    app.teardown_appcontext(close_db)
    app.before_request(load_user)
    app.before_request(check_csrf)
    app.jinja_env.globals["csrf_token"] = csrf_token

    @app.template_filter("dt")
    def fmt_dt(v):
        return str(v)[:16] if v else ""

    from .blueprints import admin, advert, auth, report
    for bp in (auth.bp, advert.bp, report.bp, admin.bp):
        app.register_blueprint(bp)

    @app.errorhandler(403)
    def forbidden(_e):
        return render_template("error.html", code=403, message="You do not have permission to open this page."), 403

    @app.errorhandler(404)
    def missing(_e):
        return render_template("error.html", code=404, message="That page was not found."), 404

    @app.errorhandler(400)
    def bad(e):
        return render_template("error.html", code=400, message=getattr(e, "description", "Bad request.")), 400

    @app.after_request
    def headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        return resp

    @app.cli.command("init-db")
    def init_db_cmd():
        """Create tables, starter rules and tips."""
        init_db()
        click.echo("Tables and starter rules created. Run 'flask --app run create-admin' next.")

    @app.cli.command("create-admin")
    @click.option("--name", prompt="Full name")
    @click.option("--email", prompt="Email")
    @click.password_option()
    def create_admin(name, email, password):
        """Create an administrator account and the starter awareness tips."""
        from .seed import SEED_TIPS
        db = get_db()
        if db.query("SELECT user_id FROM users WHERE email = %s", (email.lower(),), one=True):
            click.echo("That email is already registered.")
            return
        uid = db.execute("INSERT INTO users (full_name, email, password_hash, role, created_at) VALUES (%s,%s,%s,'administrator',%s)",
                         (name, email.lower(), generate_password_hash(password), datetime.now()))
        if not db.query("SELECT tip_id FROM awareness_tips LIMIT 1"):
            for title, content in SEED_TIPS:
                db.execute("INSERT INTO awareness_tips (created_by, title, content, created_at) VALUES (%s,%s,%s,%s)",
                           (uid, title, content, datetime.now()))
        click.echo("Administrator created.")

    return app
