"""Administrator pages: report queue, rules, users, tips, trends (FR11-FR15, FR17)."""
import re
from datetime import datetime, timedelta

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from ..db import get_db
from ..security import role_required
from ..services import text_utils as tu

bp = Blueprint("admin", __name__, url_prefix="/admin")
TACTICS = ["Asks for money", "Chat-app only", "Free email address", "Fake company", "Overseas job fee",
           "Asks for ID or bank details", "Other"]


@bp.route("/")
@role_required("administrator")
def dashboard():
    db = get_db()
    week = datetime.now() - timedelta(days=7)
    month = datetime.now() - timedelta(days=30)
    stats = {
        "pending": db.query("SELECT COUNT(*) AS n FROM scam_reports WHERE status = 'Pending'", one=True)["n"],
        "checks": db.query("SELECT COUNT(*) AS n FROM advert_checks WHERE checked_at >= %s", (week,), one=True)["n"],
        "rules": db.query("SELECT COUNT(*) AS n FROM detection_rules WHERE is_active = 1", one=True)["n"],
    }
    queue = db.query("SELECT report_id, channel, description, reported_at FROM scam_reports WHERE status = 'Pending' "
                     "ORDER BY reported_at ASC LIMIT 50")
    for q in queue:
        q["indicators"] = tu.extract_indicators(q["description"])
    tactics = db.query("SELECT tactic, COUNT(*) AS n FROM confirmed_scams WHERE confirmed_at >= %s GROUP BY tactic ORDER BY n DESC LIMIT 5", (month,))
    channels = db.query("SELECT channel, COUNT(*) AS n FROM scam_reports WHERE reported_at >= %s GROUP BY channel ORDER BY n DESC", (month,))
    top = max([t["n"] for t in tactics] + [c["n"] for c in channels] + [1])
    return render_template("admin/dashboard.html", stats=stats, queue=queue, tactics=tactics, channels=channels, top=top, tactic_options=TACTICS)


@bp.route("/reports/<int:report_id>/decide", methods=["POST"])
@role_required("administrator")
def decide(report_id):
    db = get_db()
    rep = db.query("SELECT * FROM scam_reports WHERE report_id = %s", (report_id,), one=True)
    if rep is None or rep["status"] != "Pending":
        abort(404)
    decision = request.form.get("decision")
    if decision not in ("confirm", "reject"):
        abort(400)
    scam_id = None
    if decision == "confirm":                                        # restriction R4: only on confirmation
        tactic = request.form.get("tactic", "Other")
        tactic = tactic if tactic in TACTICS else "Other"
        ind = tu.extract_indicators(rep["description"])
        entries = [("email_domain", d) for d in ind["email_domains"]] + [("link_domain", d) for d in ind["link_domains"]]
        extra = request.form.get("indicator_value", "").strip().lower()[:200]
        if extra:
            entries.append(("link_domain" if re.match(r"^[a-z0-9.-]+\.[a-z]{2,}$", extra) else "phrase", extra))
        for typ, val in entries:
            sid = db.execute("INSERT INTO confirmed_scams (tactic, indicator_type, indicator_value, confirmed_at) VALUES (%s,%s,%s,%s)",
                             (tactic, typ, val, datetime.now()))
            scam_id = scam_id or sid
    db.execute("UPDATE scam_reports SET status = %s, reviewed_by = %s, reviewed_at = %s, scam_id = %s WHERE report_id = %s",
               ("Confirmed" if decision == "confirm" else "Rejected", g.user["user_id"], datetime.now(), scam_id, report_id))
    flash("Report %d %s." % (report_id, "confirmed" if decision == "confirm" else "rejected"), "success")
    return redirect(url_for("admin.dashboard"))


# ------------------------------------------------------------------ rules (FR13)
def _rule_form():
    f = request.form
    data = {"rule_name": f.get("rule_name", "").strip()[:80], "pattern": f.get("pattern", "").strip(),
            "points": f.get("points", type=int), "reason": f.get("reason", "").strip()[:255], "tip": f.get("tip", "").strip()[:255]}
    errors = []
    if not data["rule_name"] or not data["reason"] or not data["tip"]:
        errors.append("Name, reason and tip are required.")
    if data["points"] is None or not 1 <= data["points"] <= 100:
        errors.append("Points must be a number from 1 to 100.")
    if not data["pattern"] or len(data["pattern"]) > 500:
        errors.append("Enter a pattern of up to 500 characters.")
    else:
        try:
            re.compile(data["pattern"])
        except re.error as e:
            errors.append("The pattern is not a valid regular expression: %s" % e)
    return data, errors


@bp.route("/rules")
@role_required("administrator")
def rules():
    return render_template("admin/rules.html", rules=get_db().query("SELECT * FROM detection_rules ORDER BY rule_id"))


@bp.route("/rules/new", methods=["GET", "POST"])
@role_required("administrator")
def rule_new():
    if request.method == "POST":
        data, errors = _rule_form()
        if errors:
            [flash(e, "danger") for e in errors]
            return render_template("admin/rule_form.html", rule=data, title="Add detection rule"), 400
        get_db().execute("INSERT INTO detection_rules (created_by, rule_name, pattern, points, reason, tip, is_active) VALUES (%s,%s,%s,%s,%s,%s,1)",
                         (g.user["user_id"], data["rule_name"], data["pattern"], data["points"], data["reason"], data["tip"]))
        flash("Rule added. It is used in the next check.", "success")
        return redirect(url_for("admin.rules"))
    return render_template("admin/rule_form.html", rule={}, title="Add detection rule")


@bp.route("/rules/<int:rule_id>/edit", methods=["GET", "POST"])
@role_required("administrator")
def rule_edit(rule_id):
    db = get_db()
    rule = db.query("SELECT * FROM detection_rules WHERE rule_id = %s", (rule_id,), one=True)
    if rule is None:
        abort(404)
    if request.method == "POST":
        data, errors = _rule_form()
        if errors:
            [flash(e, "danger") for e in errors]
            return render_template("admin/rule_form.html", rule=data, title="Edit detection rule"), 400
        db.execute("UPDATE detection_rules SET rule_name=%s, pattern=%s, points=%s, reason=%s, tip=%s WHERE rule_id=%s",
                   (data["rule_name"], data["pattern"], data["points"], data["reason"], data["tip"], rule_id))
        flash("Rule updated.", "success")
        return redirect(url_for("admin.rules"))
    return render_template("admin/rule_form.html", rule=rule, title="Edit detection rule")


@bp.route("/rules/<int:rule_id>/toggle", methods=["POST"])
@role_required("administrator")
def rule_toggle(rule_id):
    db = get_db()
    rule = db.query("SELECT is_active FROM detection_rules WHERE rule_id = %s", (rule_id,), one=True)
    if rule is None:
        abort(404)
    db.execute("UPDATE detection_rules SET is_active = %s WHERE rule_id = %s", (0 if rule["is_active"] else 1, rule_id))
    return redirect(url_for("admin.rules"))


# ------------------------------------------------------------------ users (FR14)
@bp.route("/users")
@role_required("administrator")
def users():
    return render_template("admin/users.html", users=get_db().query("SELECT user_id, full_name, email, role, created_at FROM users ORDER BY user_id"))


@bp.route("/users/<int:user_id>/role", methods=["POST"])
@role_required("administrator")
def user_role(user_id):
    role = request.form.get("role")
    if role not in ("job_seeker", "administrator") or user_id == g.user["user_id"]:
        flash("You cannot change your own role.", "danger")
        return redirect(url_for("admin.users"))
    get_db().execute("UPDATE users SET role = %s WHERE user_id = %s", (role, user_id))
    flash("Role updated.", "success")
    return redirect(url_for("admin.users"))


# ------------------------------------------------------------------ tips (FR17)
@bp.route("/tips", methods=["GET", "POST"])
@role_required("administrator")
def tips():
    db = get_db()
    if request.method == "POST":
        title, content = request.form.get("title", "").strip()[:120], request.form.get("content", "").strip()
        if not title or len(content) < 10:
            flash("Enter a title and a tip of at least 10 characters.", "danger")
        else:
            db.execute("INSERT INTO awareness_tips (created_by, title, content, created_at) VALUES (%s,%s,%s,%s)",
                       (g.user["user_id"], title, content, datetime.now()))
            flash("Tip published.", "success")
        return redirect(url_for("admin.tips"))
    return render_template("admin/tips.html", tips=db.query("SELECT tip_id, title, content, created_at FROM awareness_tips ORDER BY tip_id DESC"))
