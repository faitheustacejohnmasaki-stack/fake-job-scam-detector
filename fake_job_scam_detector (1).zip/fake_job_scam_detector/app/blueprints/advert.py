"""Check an advert, view results and history, read awareness tips (FR3-FR9, FR16)."""
from datetime import datetime

from flask import Blueprint, abort, current_app, flash, g, redirect, render_template, request, session, url_for

from ..db import get_db
from ..security import login_required
from ..services import text_utils as tu

bp = Blueprint("advert", __name__)

EXAMPLES = {
    "scam": "URGENT!! Earn KSH 150,000 weekly from home. No interview needed, you are hired immediately. "
            "Pay a registration fee of KSH 2,000 to start. Contact us on WhatsApp only: 0712 345 678 or apply at jobs.hr2024@gmail.com",
    "borderline": "Customer care agent needed urgently. Diploma required. Salary KSH 35,000. Send your CV to recruit.kenya@gmail.com. "
                  "Interviews will be held next week.",
    "genuine": "Graduate trainee, IT support. Bachelor's degree in IT and one year of experience. Apply through our careers page at "
               "www.acmeafrica.co.ke/careers before 30 November. Shortlisted candidates will be invited for an interview at our Nairobi office.",
}


def run_check(text, sender):
    """The core of the system: the steps of Figure 4.3 and Figure 4.6."""
    app = current_app
    db = get_db()
    text = tu.clean_text(text)
    ind = tu.extract_indicators(text, sender)                       # 4: cleanText, extractIndicators
    rules = db.query("SELECT * FROM detection_rules WHERE is_active = 1")                  # 5: getActiveRules
    confirmed = db.query("SELECT tactic, indicator_type, indicator_value FROM confirmed_scams")  # getConfirmedScams
    rule_score, hits, extra = app.extensions["rule_engine"].score_advert(text, rules, ind, confirmed, sender)  # 7
    ml_score = app.extensions["ml"].predict(text)                                            # 9: predict
    final, level = app.extensions["rater"].combine_scores(rule_score, ml_score)              # 11: combineScores
    sender_dom = tu.domain_of_email(sender) or (ind["email_domains"][0] if ind["email_domains"] else None)
    link_dom = ind["link_domains"][0] if ind["link_domains"] else None
    check_id = db.execute(                                                                    # 13: saveCheck (masked)
        "INSERT INTO advert_checks (user_id, advert_text_masked, sender_domain, link_domain, rule_score, ml_score, "
        "final_score, risk_level, checked_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
        (g.user["user_id"], tu.mask_text(text), sender_dom, link_dom, rule_score,
         None if ml_score is None else round(ml_score, 3), final, level, datetime.now()))
    for h in hits:
        db.execute("INSERT INTO check_rule_hits (check_id, rule_id, points_awarded) VALUES (%s,%s,%s)",
                   (check_id, h["rule_id"], h["points"]))
    return check_id, {"final": final, "level": level, "reasons": hits + extra, "ml_used": ml_score is not None}


@bp.route("/check", methods=["GET", "POST"])
@login_required
def check():
    if request.method == "POST":
        text = request.form.get("advert", "")
        sender = request.form.get("sender", "").strip()[:200]
        err = tu.validate_advert(text, current_app.config["MIN_ADVERT_CHARS"], current_app.config["MAX_ADVERT_CHARS"])
        if err:
            flash(err, "danger")
            return render_template("check.html", examples=EXAMPLES, advert=text, sender=sender), 400
        check_id, result = run_check(text, sender)
        session["last_result"] = {"check_id": check_id, **result}
        return redirect(url_for("advert.result", check_id=check_id))
    return render_template("check.html", examples=EXAMPLES, advert="", sender="")


def _load_check(check_id):
    row = get_db().query("SELECT * FROM advert_checks WHERE check_id = %s AND user_id = %s",
                         (check_id, g.user["user_id"]), one=True)      # restriction R3: own checks only
    if row is None:
        abort(404)
    return row


@bp.route("/result/<int:check_id>")
@login_required
def result(check_id):
    row = _load_check(check_id)
    cached = session.get("last_result")
    if cached and cached["check_id"] == check_id:
        reasons = cached["reasons"]
    else:
        reasons = get_db().query(
            "SELECT r.rule_name, h.points_awarded AS points, r.reason, r.tip FROM check_rule_hits h "
            "JOIN detection_rules r ON r.rule_id = h.rule_id WHERE h.check_id = %s ORDER BY h.points_awarded DESC", (check_id,))
    reasons = sorted(reasons, key=lambda r: -r["points"])
    return render_template("result.html", check=row, reasons=reasons)


@bp.route("/history")
@login_required
def history():
    page = max(request.args.get("page", 1, type=int), 1)
    per = 10
    db = get_db()
    total = db.query("SELECT COUNT(*) AS n FROM advert_checks WHERE user_id = %s", (g.user["user_id"],), one=True)["n"]
    rows = db.query("SELECT check_id, advert_text_masked, risk_level, final_score, checked_at FROM advert_checks "
                    "WHERE user_id = %s ORDER BY checked_at DESC, check_id DESC LIMIT %s OFFSET %s",
                    (g.user["user_id"], per, (page - 1) * per))
    return render_template("history.html", rows=rows, page=page, pages=max((total + per - 1) // per, 1))


@bp.route("/tips")
@login_required
def tips():
    rows = get_db().query("SELECT title, content, created_at FROM awareness_tips ORDER BY created_at DESC, tip_id DESC")
    return render_template("tips.html", tips=rows)
