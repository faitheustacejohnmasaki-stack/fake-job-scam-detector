"""Register, log in and log out (FR1, FR2)."""
import re
from datetime import datetime

from flask import Blueprint, current_app, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from ..db import get_db

bp = Blueprint("auth", __name__)
EMAIL_OK = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
# a real hash of a throw-away password, so a login for an unknown email takes the same time
DUMMY_HASH = generate_password_hash("not-a-real-password")


@bp.route("/")
def home():
    if g.user:
        return redirect(url_for("admin.dashboard" if g.user["role"] == "administrator" else "advert.check"))
    return redirect(url_for("auth.login"))


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        errors = []
        if not 2 <= len(name) <= 100:
            errors.append("Enter your full name.")
        if not EMAIL_OK.match(email) or len(email) > 120:
            errors.append("Enter a valid email address.")
        if len(pw) < 8:
            errors.append("The password must have at least 8 characters.")
        db = get_db()
        if not errors and db.query("SELECT user_id FROM users WHERE email = %s", (email,), one=True):
            errors.append("That email address is already registered.")      # restriction R1
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("login.html", tab="register", form=request.form), 400
        db.execute("INSERT INTO users (full_name, email, password_hash, role, created_at) VALUES (%s,%s,%s,'job_seeker',%s)",
                   (name, email, generate_password_hash(pw), datetime.now()))
        flash("Account created. Please log in.", "success")
        return redirect(url_for("auth.login"))
    return render_template("login.html", tab="register", form={})


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        ip = request.remote_addr or "?"
        cfg = current_app.config
        from ..security import clear_fails, record_fail, throttled
        if throttled(email, ip, cfg["LOGIN_MAX_FAILS"], cfg["LOGIN_LOCK_SECONDS"]):
            flash("Too many failed attempts. Please wait a few minutes and try again.", "danger")
            return render_template("login.html", tab="login", form=request.form), 429
        user = get_db().query("SELECT * FROM users WHERE email = %s", (email,), one=True)
        ok = check_password_hash(user["password_hash"] if user else DUMMY_HASH, pw) and user is not None
        if not ok:
            record_fail(email, ip)
            flash("Wrong email or password.", "danger")                     # restriction R6: one message
            return render_template("login.html", tab="login", form=request.form), 401
        clear_fails(email, ip)
        session.clear()
        session["user_id"] = user["user_id"]
        session["role"] = user["role"]
        nxt = request.args.get("next", "")
        if nxt.startswith("/") and not nxt.startswith("//"):
            return redirect(nxt)
        return redirect(url_for("auth.home"))
    return render_template("login.html", tab="login", form={})


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))
