"""Report a suspicious advert (FR10)."""
from datetime import datetime

from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from ..db import get_db
from ..security import login_required

bp = Blueprint("report", __name__)
CHANNELS = ["WhatsApp", "Telegram", "Email", "Social media", "Website", "Other"]


@bp.route("/report", methods=["GET", "POST"])
@login_required
def report():
    prefill = ""
    cid = request.args.get("check_id", type=int)
    if cid:                      # "Report this advert" from the result page pre-fills the masked text
        row = get_db().query("SELECT advert_text_masked FROM advert_checks WHERE check_id = %s AND user_id = %s",
                             (cid, g.user["user_id"]), one=True)
        prefill = row["advert_text_masked"] if row else ""
    if request.method == "POST":
        desc = request.form.get("description", "").strip()
        channel = request.form.get("channel", "")
        if len(desc) < 10 or len(desc) > 3000 or channel not in CHANNELS:
            flash("Describe what happened (at least 10 characters) and choose where you saw it.", "danger")
            return render_template("report.html", channels=CHANNELS, desc=desc, channel=channel), 400
        get_db().execute("INSERT INTO scam_reports (user_id, description, channel, status, reported_at) VALUES (%s,%s,%s,'Pending',%s)",
                         (g.user["user_id"], desc, channel, datetime.now()))
        flash("Thank you. Your report was sent to the administrators for review.", "success")
        return redirect(url_for("advert.check"))
    return render_template("report.html", channels=CHANNELS, desc=prefill, channel="")
