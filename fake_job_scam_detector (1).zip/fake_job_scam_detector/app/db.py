"""Thin database layer. All SQL uses %s placeholders and is parameterised (restriction R2).
Works with MySQL (PyMySQL) in production and SQLite for local testing."""
import os
import sqlite3
from urllib.parse import urlparse, unquote

from flask import current_app, g


class Database:
    def __init__(self, url):
        p = urlparse(url)
        self.kind = "sqlite" if p.scheme == "sqlite" else "mysql"
        if self.kind == "sqlite":
            path = unquote(p.path[1:]) if p.netloc == "" else p.netloc + p.path
            self.conn = sqlite3.connect(path or ":memory:")
            self.conn.row_factory = sqlite3.Row
            self.conn.execute("PRAGMA foreign_keys = ON")
        else:
            import pymysql
            from pymysql.cursors import DictCursor
            self.conn = pymysql.connect(host=p.hostname or "localhost", port=p.port or 3306,
                                        user=unquote(p.username or ""), password=unquote(p.password or ""),
                                        database=p.path.lstrip("/"), charset="utf8mb4",
                                        cursorclass=DictCursor, autocommit=True)

    def _sql(self, sql):
        return sql.replace("%s", "?") if self.kind == "sqlite" else sql

    def query(self, sql, args=(), one=False):
        cur = self.conn.cursor()
        cur.execute(self._sql(sql), tuple(args))
        rows = [dict(r) for r in cur.fetchall()]
        cur.close()
        return (rows[0] if rows else None) if one else rows

    def execute(self, sql, args=()):
        cur = self.conn.cursor()
        cur.execute(self._sql(sql), tuple(args))
        last = cur.lastrowid
        cur.close()
        if self.kind == "sqlite":
            self.conn.commit()
        return last

    def run_script(self, script):
        for stmt in [s.strip() for s in script.split(";") if s.strip()]:
            self.execute(stmt)

    def close(self):
        self.conn.close()


def get_db():
    if "db" not in g:
        g.db = Database(current_app.config["DATABASE_URL"])
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create the tables and the starter detection rules and awareness tips."""
    from .seed import SEED_RULES, SEED_TIPS
    db = get_db()
    schema = "schema_sqlite.sql" if db.kind == "sqlite" else "schema_mysql.sql"
    root = os.path.dirname(current_app.root_path)
    with open(os.path.join(root, schema), encoding="utf8") as f:
        db.run_script(f.read())
    if not db.query("SELECT rule_id FROM detection_rules LIMIT 1"):
        for r in SEED_RULES:
            db.execute("INSERT INTO detection_rules (rule_name, pattern, points, reason, tip, is_active) "
                       "VALUES (%s,%s,%s,%s,%s,1)", (r[0], r[2], r[1], r[3], r[4]))
    return SEED_TIPS
