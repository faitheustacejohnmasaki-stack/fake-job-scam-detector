"""Password hashing, role checks, CSRF protection and a simple login throttle (NFR3)."""
import secrets
import time
from functools import wraps

from flask import abort, flash, g, redirect, request, session, url_for

from .db import get_db

_fails = {}      # (email, ip) -> [timestamps]; in memory is enough for a single server


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]


def check_csrf():
    if request.method == "POST":
        sent = request.form.get("csrf_token", "")
        if not sent or not secrets.compare_digest(sent, session.get("csrf", "")):
            abort(400, "Invalid or missing security token. Reload the page and try again.")


def load_user():
    g.user = None
    uid = session.get("user_id")
    if uid:
        g.user = get_db().query("SELECT user_id, full_name, email, role FROM users WHERE user_id = %s", (uid,), one=True)
        if g.user is None:
            session.clear()


def login_required(view):
    @wraps(view)
    def wrapped(*a, **k):
        if g.user is None:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("auth.login", next=request.path))
        return view(*a, **k)
    return wrapped


def role_required(role):
    def deco(view):
        @wraps(view)
        @login_required
        def wrapped(*a, **k):
            if g.user["role"] != role:
                abort(403)                      # restriction R3
            return view(*a, **k)
        return wrapped
    return deco


def throttled(email, ip, max_fails, window):
    now = time.time()
    recent = [t for t in _fails.get((email, ip), []) if now - t < window]
    _fails[(email, ip)] = recent
    return len(recent) >= max_fails


def record_fail(email, ip):
    _fails.setdefault((email, ip), []).append(time.time())


def clear_fails(email, ip):
    _fails.pop((email, ip), None)
