"""ML Classifier: TF-IDF + logistic regression trained on the EMSCAD dataset (FR6)."""
import os

import joblib


class MLClassifier:
    def __init__(self, path):
        self.path = path
        self.model = joblib.load(path) if os.path.exists(path) else None

    @property
    def available(self):
        return self.model is not None

    def predict(self, text):
        """Probability (0..1) that the advert is fraudulent, or None if no model is installed."""
        if not self.available:
            return None
        return float(self.model.predict_proba([text])[0][1])
