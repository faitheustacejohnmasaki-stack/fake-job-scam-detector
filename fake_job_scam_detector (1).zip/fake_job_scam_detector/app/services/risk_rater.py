"""Risk Rater: combines the rule score and ML score into Low, Medium or High (FR7)."""


class RiskRater:
    def __init__(self, rule_w, ml_w, low_below, high_from):
        self.rule_w, self.ml_w, self.low_below, self.high_from = rule_w, ml_w, low_below, high_from

    def combine_scores(self, rule_score, ml_score):
        if ml_score is None:                       # no model installed: rules only
            final = rule_score
        else:
            final = round(self.rule_w * rule_score + self.ml_w * ml_score * 100)
        final = max(0, min(100, int(final)))
        if final < self.low_below:
            level = "Low"
        elif final < self.high_from:
            level = "Medium"
        else:
            level = "High"
        return final, level
