"""Rule Engine: applies the active detection rules and confirmed scam indicators (FR5)."""
import re

CONFIRMED_POINTS = 40


class RuleEngine:
    def score_advert(self, text, rules, indicators, confirmed, sender=""):
        """Return (rule_score, hits, extra_reasons).
        hits are the detection rules that matched (saved in check_rule_hits)."""
        haystack = "%s\n%s" % (text, sender or "")
        hits, total = [], 0
        for rule in rules:
            if not rule.get("is_active"):
                continue
            try:
                found = re.search(rule["pattern"], haystack, re.I)
            except re.error:
                continue                      # a bad pattern never breaks a check
            if found:
                hits.append({"rule_id": rule["rule_id"], "rule_name": rule["rule_name"],
                             "points": int(rule["points"]), "reason": rule["reason"], "tip": rule["tip"]})
                total += int(rule["points"])
        extra = []
        for c in confirmed:
            v = (c["indicator_value"] or "").lower()
            t = c["indicator_type"]
            matched = ((t == "email_domain" and v in indicators["email_domains"]) or
                       (t == "link_domain" and v in indicators["link_domains"]) or
                       (t == "phrase" and v and v in text.lower()))
            if matched:
                total += CONFIRMED_POINTS
                extra.append({"rule_name": "Matches a confirmed scam", "points": CONFIRMED_POINTS,
                              "reason": "This %s (%s) was reported and confirmed as a scam (%s)." % (
                                  t.replace("_", " "), c["indicator_value"], c["tactic"]),
                              "tip": "Do not reply or pay. Report anything similar you receive."})
        return min(total, 100), hits, extra
