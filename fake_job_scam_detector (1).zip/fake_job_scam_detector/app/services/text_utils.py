"""Input validation, text cleaning, indicator extraction and masking (FR4, NFR4)."""
import re

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@([A-Za-z0-9.-]+\.[A-Za-z]{2,})")
URL_RE = re.compile(r"(?:https?://|www\.)([A-Za-z0-9.-]+\.[A-Za-z]{2,})(?:[/\w\-.?%&=#]*)", re.I)
BARE_LINK_RE = re.compile(r"\b((?:bit\.ly|tinyurl\.com|t\.co|wa\.me|t\.me|cutt\.ly|rb\.gy|is\.gd)/[\w\-]+)", re.I)
PHONE_RE = re.compile(r"(?<!\w)(?:\+?254|0)[\s-]?[17]\d{2}[\s-]?\d{3}[\s-]?\d{3}(?!\w)")


def validate_advert(text, min_chars, max_chars):
    """Return an error message, or None if the advert can be analysed (restriction R1)."""
    text = (text or "").strip()
    if len(text) < min_chars:
        return "Paste the full advert or message (at least %d characters)." % min_chars
    if len(text) > max_chars:
        return "That advert is too long. Please paste up to %d characters." % max_chars
    return None


def clean_text(text):
    text = re.sub(r"[\u200b\u200c\u200d\ufeff]", "", text or "")
    return re.sub(r"\s+", " ", text).strip()


def domain_of_email(email):
    m = EMAIL_RE.search(email or "")
    return m.group(1).lower() if m else None


def extract_indicators(text, sender=""):
    """Return emails' domains, link domains and phone numbers found in the advert and sender field."""
    blob = "%s %s" % (text or "", sender or "")
    email_domains = sorted({m.group(1).lower() for m in EMAIL_RE.finditer(blob)})
    link_domains = {m.group(1).lower() for m in URL_RE.finditer(blob)}
    link_domains |= {m.group(1).split("/")[0].lower() for m in BARE_LINK_RE.finditer(blob)}
    # an email domain is not a link domain
    link_domains -= set(email_domains)
    phones = sorted({re.sub(r"[\s-]", "", m.group(0)) for m in PHONE_RE.finditer(blob)})
    return {"email_domains": email_domains, "link_domains": sorted(link_domains), "phones": phones}


def mask_text(text):
    """Replace emails and phone numbers with placeholders before anything is saved (R8)."""
    text = EMAIL_RE.sub("[email hidden]", text)
    text = PHONE_RE.sub("[phone hidden]", text)
    return text
