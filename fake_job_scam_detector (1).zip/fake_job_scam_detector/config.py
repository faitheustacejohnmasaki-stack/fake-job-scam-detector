import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-only-change-me")
    DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///dev.db")
    MODEL_PATH = os.environ.get("MODEL_PATH", "models/scam_model.joblib")
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "0") == "1"
    MAX_CONTENT_LENGTH = 64 * 1024          # reject request bodies above 64 KB
    MIN_ADVERT_CHARS = 30                   # restriction R1: too short to analyse
    MAX_ADVERT_CHARS = 5000
    RULE_WEIGHT = 0.6                       # final score = 60% rules + 40% ML
    ML_WEIGHT = 0.4
    LOW_BELOW = 25                          # 0-24 Low, 25-54 Medium, 55+ High
    HIGH_FROM = 55
    LOGIN_MAX_FAILS = 5
    LOGIN_LOCK_SECONDS = 300
