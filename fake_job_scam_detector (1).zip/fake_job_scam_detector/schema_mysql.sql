-- Fake Job Scam Detector: MySQL schema (matches Figure 4.11 of Chapter 4)
CREATE TABLE IF NOT EXISTS users (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('job_seeker','administrator') NOT NULL DEFAULT 'job_seeker',
  created_at    DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS awareness_tips (
  tip_id     INT AUTO_INCREMENT PRIMARY KEY,
  created_by INT NOT NULL,
  title      VARCHAR(120) NOT NULL,
  content    TEXT NOT NULL,
  created_at DATETIME NOT NULL,
  FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS detection_rules (
  rule_id    INT AUTO_INCREMENT PRIMARY KEY,
  created_by INT NULL,
  rule_name  VARCHAR(80)  NOT NULL,
  pattern    VARCHAR(500) NOT NULL,
  points     INT NOT NULL,
  reason     VARCHAR(255) NOT NULL,
  tip        VARCHAR(255) NOT NULL,
  is_active  BOOLEAN NOT NULL DEFAULT 1,
  FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS advert_checks (
  check_id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id            INT NOT NULL,
  advert_text_masked TEXT NOT NULL,
  sender_domain      VARCHAR(120) NULL,
  link_domain        VARCHAR(120) NULL,
  rule_score         INT NOT NULL,
  ml_score           DECIMAL(4,3) NULL,
  final_score        INT NOT NULL,
  risk_level         ENUM('Low','Medium','High') NOT NULL,
  checked_at         DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS check_rule_hits (
  check_id       INT NOT NULL,
  rule_id        INT NOT NULL,
  points_awarded INT NOT NULL,
  PRIMARY KEY (check_id, rule_id),
  FOREIGN KEY (check_id) REFERENCES advert_checks(check_id) ON DELETE CASCADE,
  FOREIGN KEY (rule_id)  REFERENCES detection_rules(rule_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS confirmed_scams (
  scam_id         INT AUTO_INCREMENT PRIMARY KEY,
  tactic          VARCHAR(80)  NOT NULL,
  indicator_type  ENUM('email_domain','link_domain','phrase') NOT NULL,
  indicator_value VARCHAR(200) NOT NULL,
  confirmed_at    DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scam_reports (
  report_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  reviewed_by INT NULL,
  scam_id     INT NULL,
  description TEXT NOT NULL,
  channel     ENUM('WhatsApp','Telegram','Email','Social media','Website','Other') NOT NULL,
  status      ENUM('Pending','Confirmed','Rejected') NOT NULL DEFAULT 'Pending',
  reported_at DATETIME NOT NULL,
  reviewed_at DATETIME NULL,
  FOREIGN KEY (user_id)     REFERENCES users(user_id),
  FOREIGN KEY (reviewed_by) REFERENCES users(user_id),
  FOREIGN KEY (scam_id)     REFERENCES confirmed_scams(scam_id)
) ENGINE=InnoDB;
