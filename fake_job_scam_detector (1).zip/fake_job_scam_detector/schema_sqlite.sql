-- Same tables as schema_mysql.sql, written for SQLite (quick local testing and the unit tests).
CREATE TABLE IF NOT EXISTS users (
  user_id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'job_seeker' CHECK (role IN ('job_seeker','administrator')),
  created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS awareness_tips (
  tip_id INTEGER PRIMARY KEY AUTOINCREMENT, created_by INTEGER NOT NULL REFERENCES users(user_id),
  title TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS detection_rules (
  rule_id INTEGER PRIMARY KEY AUTOINCREMENT, created_by INTEGER NULL REFERENCES users(user_id),
  rule_name TEXT NOT NULL, pattern TEXT NOT NULL, points INTEGER NOT NULL, reason TEXT NOT NULL,
  tip TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS advert_checks (
  check_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(user_id),
  advert_text_masked TEXT NOT NULL, sender_domain TEXT NULL, link_domain TEXT NULL, rule_score INTEGER NOT NULL,
  ml_score REAL NULL, final_score INTEGER NOT NULL, risk_level TEXT NOT NULL CHECK (risk_level IN ('Low','Medium','High')),
  checked_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS check_rule_hits (
  check_id INTEGER NOT NULL REFERENCES advert_checks(check_id) ON DELETE CASCADE,
  rule_id INTEGER NOT NULL REFERENCES detection_rules(rule_id), points_awarded INTEGER NOT NULL,
  PRIMARY KEY (check_id, rule_id));
CREATE TABLE IF NOT EXISTS confirmed_scams (
  scam_id INTEGER PRIMARY KEY AUTOINCREMENT, tactic TEXT NOT NULL,
  indicator_type TEXT NOT NULL CHECK (indicator_type IN ('email_domain','link_domain','phrase')),
  indicator_value TEXT NOT NULL, confirmed_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS scam_reports (
  report_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(user_id),
  reviewed_by INTEGER NULL REFERENCES users(user_id), scam_id INTEGER NULL REFERENCES confirmed_scams(scam_id),
  description TEXT NOT NULL,
  channel TEXT NOT NULL CHECK (channel IN ('WhatsApp','Telegram','Email','Social media','Website','Other')),
  status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','Confirmed','Rejected')),
  reported_at TEXT NOT NULL, reviewed_at TEXT NULL);
