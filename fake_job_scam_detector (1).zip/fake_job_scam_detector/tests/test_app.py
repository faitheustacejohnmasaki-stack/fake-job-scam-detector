import os
import re
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app                               # noqa: E402
from app.db import get_db, init_db                       # noqa: E402
from werkzeug.security import generate_password_hash     # noqa: E402
from datetime import datetime                            # noqa: E402

SCAM = ("URGENT!! Earn KSH 150,000 weekly from home. No interview needed. Pay a registration fee of KSH 2,000. "
        "WhatsApp only 0712 345 678, apply at jobs.hr2024@gmail.com")
GOOD = ("Graduate trainee IT support. Bachelor's degree and one year of experience. Apply on www.acmeafrica.co.ke/careers. "
        "Shortlisted candidates will be invited to an interview.")


@pytest.fixture()
def client(tmp_path):
    app = create_app({"TESTING": True, "DATABASE_URL": "sqlite:///%s" % (tmp_path / "t.db"), "MODEL_PATH": str(tmp_path / "none.joblib")})
    with app.app_context():
        init_db()
        db = get_db()
        db.execute("INSERT INTO users (full_name,email,password_hash,role,created_at) VALUES (%s,%s,%s,'administrator',%s)",
                   ("Admin One", "admin@x.com", generate_password_hash("adminpass1"), datetime.now()))
    return app.test_client()


def token(c, url="/login"):
    html = c.get(url).get_data(as_text=True)
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)


def post(c, url, data, page="/login"):
    data = dict(data); data["csrf_token"] = token(c, page)
    return c.post(url, data=data, follow_redirects=False)


def register_login(c, email="js@x.com", pw="password1"):
    post(c, "/register", {"full_name": "Jane Seeker", "email": email, "password": pw})
    return post(c, "/login", {"email": email, "password": pw})


def test_register_login_and_generic_error(client):
    assert register_login(client).status_code == 302
    c2 = client.application.test_client()
    r = post(c2, "/login", {"email": "js@x.com", "password": "wrong"})
    r2 = post(c2, "/login", {"email": "nobody@x.com", "password": "wrong"})
    assert r.status_code == r2.status_code == 401
    assert b"Wrong email or password" in r.data and b"Wrong email or password" in r2.data     # R6


def test_duplicate_email_and_short_password_rejected(client):
    register_login(client)
    c2 = client.application.test_client()
    assert post(c2, "/register", {"full_name": "X Y", "email": "js@x.com", "password": "password1"}).status_code == 400
    assert post(c2, "/register", {"full_name": "X Y", "email": "n@x.com", "password": "short"}).status_code == 400


def test_password_is_hashed(client):
    register_login(client)
    with client.application.app_context():
        h = get_db().query("SELECT password_hash FROM users WHERE email='js@x.com'", one=True)["password_hash"]
    assert "password1" not in h                                                            # R7


def test_csrf_blocks_post_without_token(client):
    assert client.post("/login", data={"email": "a@b.com", "password": "x"}).status_code == 400


def test_scam_is_high_risk_and_masked(client):
    register_login(client)
    r = post(client, "/check", {"advert": SCAM, "sender": ""}, "/check")
    assert r.status_code == 302
    page = client.get(r.headers["Location"]).get_data(as_text=True)
    assert "HIGH RISK" in page and "Asks for money" in page
    with client.application.app_context():
        row = get_db().query("SELECT * FROM advert_checks", one=True)
        assert "0712" not in row["advert_text_masked"] and "jobs.hr2024@gmail.com" not in row["advert_text_masked"]   # R8
        assert row["sender_domain"] == "gmail.com"
        assert get_db().query("SELECT COUNT(*) AS n FROM check_rule_hits", one=True)["n"] >= 3


def test_genuine_advert_is_low(client):
    register_login(client)
    r = post(client, "/check", {"advert": GOOD, "sender": "hr@acmeafrica.co.ke"}, "/check")
    assert "LOW RISK" in client.get(r.headers["Location"]).get_data(as_text=True)


def test_short_advert_rejected(client):
    register_login(client)
    assert post(client, "/check", {"advert": "hi", "sender": ""}, "/check").status_code == 400    # R1


def test_user_cannot_open_admin_or_other_history(client):
    register_login(client)
    assert client.get("/admin/").status_code == 403                                              # R3
    assert client.get("/admin/rules").status_code == 403
    r = post(client, "/check", {"advert": SCAM, "sender": ""}, "/check")
    other = client.application.test_client()
    register_login(other, "two@x.com")
    assert other.get(r.headers["Location"]).status_code == 404


def test_report_confirm_flow_updates_later_checks(client):
    register_login(client)
    post(client, "/report", {"description": "Fee asked for a job via fastjobs-kenya.com, contact hr@fastjobs-kenya.com", "channel": "WhatsApp"}, "/report")
    admin = client.application.test_client()
    post(admin, "/login", {"email": "admin@x.com", "password": "adminpass1"})
    assert b"fastjobs-kenya.com" in admin.get("/admin/").data
    post(admin, "/admin/reports/1/decide", {"decision": "confirm", "tactic": "Asks for money"}, "/admin/")
    with client.application.app_context():
        assert get_db().query("SELECT status FROM scam_reports", one=True)["status"] == "Confirmed"
        assert get_db().query("SELECT COUNT(*) AS n FROM confirmed_scams", one=True)["n"] >= 1
    r = post(client, "/check", {"advert": "Great role, please send your CV to the team at hr@fastjobs-kenya.com for consideration this week.", "sender": ""}, "/check")
    assert b"Matches a confirmed scam" in client.get(r.headers["Location"]).data


def test_rejected_report_creates_no_confirmed_scam(client):                                       # R4
    register_login(client)
    post(client, "/report", {"description": "Something about spam@bad-domain.com maybe", "channel": "Email"}, "/report")
    admin = client.application.test_client()
    post(admin, "/login", {"email": "admin@x.com", "password": "adminpass1"})
    post(admin, "/admin/reports/1/decide", {"decision": "reject"}, "/admin/")
    with client.application.app_context():
        assert get_db().query("SELECT COUNT(*) AS n FROM confirmed_scams", one=True)["n"] == 0


def test_admin_rule_management(client):
    admin = client.application.test_client()
    post(admin, "/login", {"email": "admin@x.com", "password": "adminpass1"})
    bad = post(admin, "/admin/rules/new", {"rule_name": "x", "pattern": "([", "points": "10", "reason": "r", "tip": "t"}, "/admin/rules/new")
    assert bad.status_code == 400
    ok = post(admin, "/admin/rules/new", {"rule_name": "Crypto", "pattern": "bitcoin", "points": "30", "reason": "r", "tip": "t"}, "/admin/rules/new")
    assert ok.status_code == 302
    post(admin, "/admin/rules/10/toggle", {}, "/admin/rules")
    register_login(client)
    r = post(client, "/check", {"advert": "Invest in bitcoin and earn with our company, contact the recruitment desk today please.", "sender": ""}, "/check")
    assert b"Crypto" not in client.get(r.headers["Location"]).data                                  # disabled rule not used


def test_ml_model_is_used_when_installed(tmp_path):
    import subprocess
    root = os.path.dirname(os.path.dirname(__file__))
    out = str(tmp_path / "m.joblib")
    subprocess.run([sys.executable, "train_model.py", "--demo", "--out", out], cwd=root, check=True, capture_output=True)
    app = create_app({"TESTING": True, "DATABASE_URL": "sqlite:///%s" % (tmp_path / "t2.db"), "MODEL_PATH": out})
    assert app.extensions["ml"].available
    p_scam = app.extensions["ml"].predict(SCAM)
    p_good = app.extensions["ml"].predict(GOOD)
    assert p_scam > p_good
