"""Train the scam classifier and save it to models/scam_model.joblib.

Usage:
    python train_model.py --csv data/fake_job_postings.csv     # EMSCAD dataset (Kaggle / UCI)
    python train_model.py --demo                               # tiny built-in demo set (testing only)
"""
import argparse
import os

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

DEMO = [
    ("Earn KSH 150,000 weekly from home. No interview. Pay registration fee of 2,000 to start. WhatsApp only.", 1),
    ("Urgent hiring! Dubai jobs, visa processing fee required, send your passport copy and ID today.", 1),
    ("Congratulations you are hired immediately. Send deposit via Mpesa till to confirm your slot.", 1),
    ("Work from home data entry earn $500 per day easy. Contact us on Telegram. Training fee refundable.", 1),
    ("You have been selected without an interview. Share bank details and OTP to receive your salary advance.", 1),
    ("Limited slots! Apply today via bit.ly link, pay small processing fee, gmail contact only.", 1),
    ("Graduate trainee, IT support. Bachelor's degree in IT, 1 year experience. Apply through our careers page. Interviews at our Nairobi office.", 0),
    ("Customer care agent needed. Diploma required, shifts in Westlands. Send CV to hr@company.co.ke. Shortlisted candidates will be interviewed.", 0),
    ("Accountant wanted. CPA part II, 3 years experience, competitive salary per the company scale. Apply on our website before the deadline.", 0),
    ("Software developer, Python and SQL, hybrid work in Nairobi. Technical interview and reference checks apply.", 0),
    ("Sales executive for a pharmaceutical distributor. Commission and base salary. Submit your CV on the portal.", 0),
    ("Teaching assistant for a primary school in Kisumu. TSC registration preferred. Panel interview in March.", 0),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", help="EMSCAD fake_job_postings.csv")
    ap.add_argument("--demo", action="store_true", help="train on a tiny demo set (not for real use)")
    ap.add_argument("--out", default="models/scam_model.joblib")
    a = ap.parse_args()

    if a.csv:
        df = pd.read_csv(a.csv)
        cols = [c for c in ("title", "company_profile", "description", "requirements", "benefits") if c in df]
        df["text"] = df[cols].fillna("").agg(" ".join, axis=1)
        X, y = df["text"], df["fraudulent"].astype(int)
    elif a.demo:
        X, y = pd.Series([t for t, _ in DEMO]), pd.Series([l for _, l in DEMO])
    else:
        ap.error("give --csv PATH or --demo")

    model = Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2), min_df=1 if a.demo else 3, max_features=50000)),
        ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),   # favours recall (NFR5)
    ])
    if a.demo:
        model.fit(X, y)
    else:
        Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
        model.fit(Xtr, ytr)
        print(classification_report(yte, model.predict(Xte), target_names=["genuine", "fraudulent"]))
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    joblib.dump(model, a.out)
    print("Model saved to", a.out)


if __name__ == "__main__":
    main()
